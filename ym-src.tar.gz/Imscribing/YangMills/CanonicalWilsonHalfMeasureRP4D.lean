
import Imscribing.YangMills.CanonicalWilsonMeasureBridge
import Imscribing.YangMills.LatticeSchwingerRP4D

/-!
# Canonical Product Haar Half-Lattice Measure & Unconditional Finite-Volume 4D RP
-/

namespace Imscribing.YangMills.CanonicalHalfRP4D

open MeasureTheory
open Imscribing.YangMills.WilsonLattice4D
open Imscribing.YangMills.WilsonMeasure4D
open Imscribing.YangMills.LatticeRP4D
open Imscribing.YangMills.LatticeOSRP4D
open Imscribing.YangMills.LatticeSchwingerRP4D
open Imscribing.YangMills.CanonicalHaar4D
open Imscribing.YangMills.CanonicalWilsonBridge

private lemma gaugeGroup_coe_inv_star' {N : ℕ} (A : GaugeGroup N) :
    ((A⁻¹ : GaugeGroup N) : Matrix (Fin N) (Fin N) ℂ) = star (A : Matrix (Fin N) (Fin N) ℂ) := by
  have h1 : (A : Matrix (Fin N) (Fin N) ℂ) * ((A⁻¹ : GaugeGroup N) : Matrix (Fin N) (Fin N) ℂ) = 1 := by
    change ((A * A⁻¹ : GaugeGroup N) : Matrix (Fin N) (Fin N) ℂ) = 1
    simp
  have h2 : star (A : Matrix (Fin N) (Fin N) ℂ) * (A : Matrix (Fin N) (Fin N) ℂ) = 1 :=
    Matrix.mem_unitaryGroup_iff'.mp (Matrix.mem_specialUnitaryGroup_iff.mp A.prop).1
  calc ((A⁻¹ : GaugeGroup N) : Matrix (Fin N) (Fin N) ℂ)
      = (star (A : Matrix (Fin N) (Fin N) ℂ) * (A : Matrix (Fin N) (Fin N) ℂ)) *
          ((A⁻¹ : GaugeGroup N) : Matrix (Fin N) (Fin N) ℂ) := by rw [h2, Matrix.one_mul]
    _ = star (A : Matrix (Fin N) (Fin N) ℂ) *
          ((A : Matrix (Fin N) (Fin N) ℂ) * ((A⁻¹ : GaugeGroup N) : Matrix (Fin N) (Fin N) ℂ)) := by
          rw [Matrix.mul_assoc]
    _ = star (A : Matrix (Fin N) (Fin N) ℂ) := by rw [h1, Matrix.mul_one]

private def gaugeGroupTopGrp (N : ℕ) : IsTopologicalGroup (GaugeGroup N) where
  continuous_mul := Continuous.subtype_mk
    (Continuous.mul (continuous_subtype_val.comp continuous_fst)
      (continuous_subtype_val.comp continuous_snd)) _
  continuous_inv := by
    refine Continuous.subtype_mk ?_ _
    have h_eq : (fun A : GaugeGroup N => ((A⁻¹ : GaugeGroup N) : Matrix (Fin N) (Fin N) ℂ)) =
        fun (A : GaugeGroup N) => star (A : Matrix (Fin N) (Fin N) ℂ) := funext gaugeGroup_coe_inv_star'
    try rw [h_eq]
    exact continuous_star.comp continuous_subtype_val

/-- Canonical product Haar probability measure on cut-splitting variables `Lat4 (2 * M) → SU(N)`. -/
noncomputable def cutAuxHaarMeasure (N M : ℕ) [NeZero M] :
    letI := borel (GaugeGroup N)
    Measure (Lat4 (2 * M) → GaugeGroup N) :=
  letI := borel (GaugeGroup N)
  haveI : BorelSpace (GaugeGroup N) := ⟨rfl⟩
  haveI : CompactSpace (GaugeGroup N) := compactSpace_gaugeGroup N
  haveI : IsTopologicalGroup (GaugeGroup N) := gaugeGroupTopGrp N
  Measure.pi (fun _ => (Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts (GaugeGroup N))))

/-- Canonical product Haar probability measure on `HalfVar N M`. -/
private instance instIsProbabilityMeasureCutAuxHaar (N M : ℕ) [NeZero M] :
    IsProbabilityMeasure (cutAuxHaarMeasure N M) := by
  letI := borel (GaugeGroup N)
  haveI : BorelSpace (GaugeGroup N) := ⟨rfl⟩
  haveI : SecondCountableTopology (Matrix (Fin N) (Fin N) ℂ) := by unfold Matrix; infer_instance
  haveI : SecondCountableTopology (GaugeGroup N) := (⟨rfl⟩ : Topology.IsInducing (fun A : GaugeGroup N => (A : Matrix (Fin N) (Fin N) ℂ))).secondCountableTopology
  haveI : IsTopologicalGroup (GaugeGroup N) := gaugeGroupTopGrp N
  haveI : CompactSpace (GaugeGroup N) := compactSpace_gaugeGroup N
  haveI : IsProbabilityMeasure (Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts (GaugeGroup N))) :=
    ⟨by simpa using (Measure.haarMeasure_self : (Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts (GaugeGroup N))) (⊤ : TopologicalSpace.PositiveCompacts (GaugeGroup N)) = 1)⟩
  unfold cutAuxHaarMeasure
  infer_instance

noncomputable def halfVarHaarMeasure (N M : ℕ) [NeZero M] :
    letI := borel (GaugeGroup N)
    Measure (HalfVar N M) :=
  letI := borel (GaugeGroup N)
  (wilsonHaarLinkMeasure N (2 * M)).prod (cutAuxHaarMeasure N M)

theorem halfVarHaarMeasure_isProbability (N M : ℕ) [NeZero M] :
    letI := borel (GaugeGroup N)
    @IsProbabilityMeasure (HalfVar N M) _ (halfVarHaarMeasure N M) := by
  letI := borel (GaugeGroup N)
  haveI : BorelSpace (GaugeGroup N) := ⟨rfl⟩
  haveI : CompactSpace (GaugeGroup N) := compactSpace_gaugeGroup N
  haveI : IsTopologicalGroup (GaugeGroup N) := gaugeGroupTopGrp N
  haveI := wilsonHaarLinkMeasure_isProbability N (2 * M)
  haveI : IsProbabilityMeasure (cutAuxHaarMeasure N M) := inferInstance
  exact Measure.prod.instIsProbabilityMeasure _ _

/-- **Haar Convolution Identity for the Cut-Link Split `W₁⁻¹ * W₂`:** -/
theorem haar_inv_mul_lintegral {G : Type*} [Group G] [TopologicalSpace G]
    [MeasurableSpace G] [IsTopologicalGroup G] [BorelSpace G] [MeasurableMul₂ G]
    (ν : Measure G) [IsProbabilityMeasure ν] [hL : Measure.IsMulLeftInvariant ν]
    {s : Set G} (hs : MeasurableSet s) :
    ∫⁻ W₁ : G, ∫⁻ W₂ : G, s.indicator 1 (W₁⁻¹ * W₂) ∂ν ∂ν = ν s := by
  have h_inner : ∀ W₁ : G, ∫⁻ W₂ : G, s.indicator 1 (W₁⁻¹ * W₂) ∂ν = ν s := by
    intro W₁
    have hm : Measurable (fun W₂ : G => W₁⁻¹ * W₂) := measurable_const.mul measurable_id
    have hind : Measurable (s.indicator (fun _ : G => (1 : ENNReal))) := measurable_const.indicator hs
    change (∫⁻ W₂ : G, s.indicator (fun _ => 1) (W₁⁻¹ * W₂) ∂ν) = ν s
    change (∫⁻ W₂ : G, s.indicator (fun _ => 1) (W₁⁻¹ * W₂) ∂ν) = ν s
    rw [← lintegral_map hind hm, hL.map_mul_left_eq_self W₁⁻¹, lintegral_indicator hs]
    simp
  simp_rw [h_inner, lintegral_const, measure_univ, mul_one]

/-- **Unconditional Finite-Volume 4D SU(N) Reflection Positivity on Canonical Haar Measure.** -/
theorem canonical_smeared_magnetic_rp_nonneg
    (N M : ℕ) [NeZero N] [NeZero M] {β : ℝ} (hβ : 0 ≤ β)
    {ι : Type*} (s : Finset ι) (c : ι → ℂ) (n : ι → ℕ)
    (xs : ∀ α : ι, Fin (n α) → Lat4 (2 * M))
    (hpos : ∀ α ∈ s, ∀ k : Fin (n α), ((xs α k) 0).val < M) :
    letI := borel (GaugeGroup N)
    let μ := halfVarHaarMeasure N M
    let F : LinkConfig N (2 * M) → ℂ := fun U =>
      ∑ α ∈ s, c α * ∏ k : Fin (n α), (spatialPlaqDensity N (2 * M) U (xs α k) : ℂ)
    0 ≤ (∫ p, ∫ q, star (F (linkReflect (glueConfig p q))) * F (glueConfig p q) *
      (Real.exp (-wilsonAction N (2 * M) β (glueConfig p q)) : ℂ) ∂μ ∂μ).re := by
  letI := borel (GaugeGroup N)
  haveI : BorelSpace (GaugeGroup N) := ⟨rfl⟩
  haveI : SecondCountableTopology (Matrix (Fin N) (Fin N) ℂ) := by unfold Matrix; infer_instance
  haveI : SecondCountableTopology (GaugeGroup N) := by
    have h_ind : Topology.IsInducing (fun A : GaugeGroup N => (A : Matrix (Fin N) (Fin N) ℂ)) := ⟨rfl⟩
    exact h_ind.secondCountableTopology
  haveI : MeasurableMul₂ (GaugeGroup N) := ContinuousMul.measurableMul₂
  haveI : ContinuousInv (GaugeGroup N) := by
    refine ⟨?_⟩
    have h_ind : Topology.IsInducing (fun A : GaugeGroup N => (A : Matrix (Fin N) (Fin N) ℂ)) := ⟨rfl⟩
    rw [h_ind.continuous_iff]
    change Continuous (fun A : GaugeGroup N => ((A⁻¹ : GaugeGroup N) : Matrix (Fin N) (Fin N) ℂ))
    have h_eq : (fun A : GaugeGroup N => ((A⁻¹ : GaugeGroup N) : Matrix (Fin N) (Fin N) ℂ)) =
        (fun A : GaugeGroup N => star (A : Matrix (Fin N) (Fin N) ℂ)) := by
      funext A
      first | rfl | rw [← Matrix.star_eq_inv, Matrix.specialUnitaryGroup.coe_star]
    rw [h_eq]
    exact continuous_pi fun i => continuous_pi fun j =>
      continuous_star.comp ((continuous_apply i).comp ((continuous_apply j).comp continuous_subtype_val))
  haveI : MeasurableInv (GaugeGroup N) := ContinuousInv.measurableInv
  haveI : IsTopologicalGroup (GaugeGroup N) := gaugeGroupTopGrp N
  haveI : MeasurableMul₂ (GaugeGroup N) := ContinuousMul.measurableMul₂
  haveI : MeasurableInv (GaugeGroup N) := ContinuousInv.measurableInv
  haveI := halfVarHaarMeasure_isProbability N M
  exact smeared_magnetic_wilson_rp_nonneg hβ (canonicalGaugeEntryMeasurable N)
    (halfVarHaarMeasure N M) s c n xs hpos

end Imscribing.YangMills.CanonicalHalfRP4D