import Imscribing.YangMills.CenteredLatticeTranslation4D

/-!
# Interior Non-Wrapping Shift & O((a L)⁻¹) Exterior Tail Decay
-/

namespace Imscribing.YangMills.LatticeExteriorCutoff4D

open Imscribing.YangMills.ContinuumInterfaces
open Imscribing.YangMills.WilsonLattice4D
open Imscribing.YangMills.CenteredTranslation4D

/-- Interior quarter-torus predicate preventing periodic wraparound under shifts. -/
def InInteriorBox (L n : ℕ) [NeZero L] (xs : Fin n → Lat4 L) : Prop :=
  ∀ k : Fin n, ∀ μ : Fin 4, |centeredCoord L (xs k μ)| < (L : ℤ) / 4

/-- **Exact Non-Wrapping Shift on `InInteriorBox`:** -/
theorem interior_box_shift_exact (L n : ℕ) [NeZero L] (_hL : 8 ≤ L) (a : ℝ)
    (xs : Fin n → Lat4 L) (hxs : InInteriorBox L n xs)
    (v : Lat4 L) (hv : ∀ μ : Fin 4, |centeredCoord L (v μ)| < (L : ℤ) / 4) :
    ∀ k : Fin n, centeredLatSite L a (xs k - v) =
      centeredLatSite L a (xs k) - centeredLatSite L a v := by
  intro k
  apply centeredLatSite_sub_exact L a (xs k) v
  intro μ
  exact ⟨hxs k μ, hv μ⟩

/-- **Explicit `O((a L)⁻¹)` Exterior Box Tail Bound:** -/
theorem centered_exterior_tail_bound (L n : ℕ) [NeZero L] (hL : 8 ≤ L)
    {a : ℝ} (ha0 : 0 < a) (ha1 : a ≤ 1) (f : EuclideanSchwartz n) :
    letI : ∀ xs, Decidable (InInteriorBox L n xs) := fun xs => Classical.propDecidable (InInteriorBox L n xs)
    a ^ (4 * n) * ∑ xs : Fin n → Lat4 L,
      (if InInteriorBox L n xs then 0 else ‖f (fun k => centeredLatSite L a (xs k))‖) ≤
      (8 / (a * (L : ℝ))) * (4096 : ℝ) ^ n *
        ∑ j ∈ Finset.range (8 * n + 2),
          ((8 * n + 1).choose j : ℝ) * SchwartzMap.seminorm ℂ j 0 f := by
  letI : ∀ xs, Decidable (InInteriorBox L n xs) := fun xs => Classical.propDecidable (InInteriorBox L n xs)
  have hL_pos : (0 : ℝ) < (L : ℝ) := Nat.cast_pos.mpr (NeZero.pos L)
  have h_1d := centered_1d_riemann_le_eight L ha0 ha1
  have h_4d : ∑ x : Lat4 L, ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (x μ) : ℝ)|) ^ 2) ≤ 4096 := by
    have h_prod_sum :
        (∑ x : Lat4 L, ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (x μ) : ℝ)|) ^ 2)) =
        ∏ _μ : Fin 4, ∑ v : ZMod L, a / (1 + a * |(centeredCoord L v : ℝ)|) ^ 2 :=
      (Fintype.prod_sum (fun (_ : Fin 4) (v : ZMod L) =>
        a / (1 + a * |(centeredCoord L v : ℝ)|) ^ 2)).symm
    rw [h_prod_sum, Finset.prod_const, Finset.card_univ, Fintype.card_fin]
    have h_nn : 0 ≤ ∑ v : ZMod L, a / (1 + a * |(centeredCoord L v : ℝ)|) ^ 2 :=
      Finset.sum_nonneg fun _ _ => by positivity
    calc
      (∑ v : ZMod L, a / (1 + a * |(centeredCoord L v : ℝ)|) ^ 2) ^ 4 ≤ 8 ^ 4 :=
          pow_le_pow_left₀ h_nn h_1d 4
      _ = 4096 := by norm_num
  have h_nd :
      (∑ xs : Fin n → Lat4 L, ∏ k : Fin n, ∏ μ : Fin 4,
          (a / (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2)) ≤ (4096 : ℝ) ^ n := by
    have h_prod_sum :
        (∑ xs : Fin n → Lat4 L, ∏ k : Fin n, ∏ μ : Fin 4,
          (a / (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2)) =
        ∏ _k : Fin n, ∑ x : Lat4 L, ∏ μ : Fin 4,
          (a / (1 + a * |(centeredCoord L (x μ) : ℝ)|) ^ 2) :=
      (Fintype.prod_sum (fun (_ : Fin n) (x : Lat4 L) =>
        ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (x μ) : ℝ)|) ^ 2))).symm
    rw [h_prod_sum, Finset.prod_const, Finset.card_univ, Fintype.card_fin]
    have h_nn : 0 ≤ ∑ x : Lat4 L, ∏ μ : Fin 4,
        (a / (1 + a * |(centeredCoord L (x μ) : ℝ)|) ^ 2) :=
      Finset.sum_nonneg fun _ _ => Finset.prod_nonneg fun _ _ => by positivity
    exact pow_le_pow_left₀ h_nn h_4d n
  let S_semi : ℝ := ∑ j ∈ Finset.range (8 * n + 2),
    ((8 * n + 1).choose j : ℝ) * SchwartzMap.seminorm ℂ j 0 f
  have h_pointwise : ∀ xs : Fin n → Lat4 L,
      (∏ _k : Fin n, ∏ _μ : Fin 4, a) *
          (if InInteriorBox L n xs then 0 else ‖f (fun k => centeredLatSite L a (xs k))‖) ≤
        ((8 / (a * (L : ℝ))) * S_semi) *
          (∏ k : Fin n, ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2)) := by
    intro xs
    by_cases hin : InInteriorBox L n xs
    · simp only [hin, ↓reduceIte, mul_zero]
      have hS_nn : 0 ≤ S_semi := Finset.sum_nonneg fun j _ =>
        mul_nonneg (Nat.cast_nonneg _) (apply_nonneg _ _)
      exact mul_nonneg (mul_nonneg (by positivity) hS_nn)
        (Finset.prod_nonneg fun _ _ => Finset.prod_nonneg fun _ _ => by positivity)
    · simp only [hin, ↓reduceIte]
      have h_out : ∃ k : Fin n, ∃ μ : Fin 4, (L : ℤ) / 4 ≤ |centeredCoord L (xs k μ)| := by
        unfold InInteriorBox at hin
        push_neg at hin
        exact hin
      obtain ⟨k₀, μ₀, hk₀⟩ := h_out
      let x_phys : Fin n → Spacetime4 := fun k => centeredLatSite L a (xs k)
      have h_L8 : (L : ℝ) ≤ 8 * |(centeredCoord L (xs k₀ μ₀) : ℝ)| := by
        have h_int : (L : ℤ) ≤ 8 * |centeredCoord L (xs k₀ μ₀)| := by
          have hL8 : (8 : ℤ) ≤ (L : ℤ) := by exact_mod_cast hL
          have h_div := Int.mul_ediv_add_emod (L : ℤ) 4
          have h_rem : (L : ℤ) % 4 < 4 := Int.emod_lt_of_pos (L : ℤ) (by norm_num)
          have h_ge2 : (2 : ℤ) ≤ (L : ℤ) / 4 := by linarith
          linarith
        have h_r : ((L : ℤ) : ℝ) ≤ ((8 * |centeredCoord L (xs k₀ μ₀)| : ℤ) : ℝ) := by
          exact_mod_cast h_int
        simpa using h_r
      have h_norm_ge : a * (L : ℝ) / 8 ≤ ‖x_phys‖ := by
        have h1 : a * |(centeredCoord L (xs k₀ μ₀) : ℝ)| = ‖(x_phys k₀) μ₀‖ := by
          change a * |(centeredCoord L (xs k₀ μ₀) : ℝ)| = ‖a * (centeredCoord L (xs k₀ μ₀) : ℝ)‖
          rw [Real.norm_eq_abs, abs_mul, abs_of_pos ha0]
        have h2 : ‖(x_phys k₀) μ₀‖ ≤ ‖x_phys k₀‖ := PiLp.norm_apply_le (x_phys k₀) μ₀
        have h3 : ‖x_phys k₀‖ ≤ ‖x_phys‖ := norm_le_pi_norm x_phys k₀
        have ha_L := mul_le_mul_of_nonneg_left h_L8 ha0.le
        linarith
      have h_one_le : 1 ≤ (8 / (a * (L : ℝ))) * ‖x_phys‖ := by
        have haL_pos : 0 < a * (L : ℝ) := mul_pos ha0 hL_pos
        calc
          1 = (8 / (a * (L : ℝ))) * (a * (L : ℝ) / 8) := by field_simp [haL_pos.ne']
          _ ≤ (8 / (a * (L : ℝ))) * ‖x_phys‖ :=
              mul_le_mul_of_nonneg_left h_norm_ge (by positivity)
      have h_coord_le : ∀ k : Fin n, ∀ μ : Fin 4,
          1 + a * |(centeredCoord L (xs k μ) : ℝ)| ≤ 1 + ‖x_phys‖ := by
        intro k μ
        have h1 : a * |(centeredCoord L (xs k μ) : ℝ)| = ‖(x_phys k) μ‖ := by
          change a * |(centeredCoord L (xs k μ) : ℝ)| = ‖a * (centeredCoord L (xs k μ) : ℝ)‖
          rw [Real.norm_eq_abs, abs_mul, abs_of_pos ha0]
        have h2 : ‖(x_phys k) μ‖ ≤ ‖x_phys k‖ := PiLp.norm_apply_le (x_phys k) μ
        have h3 : ‖x_phys k‖ ≤ ‖x_phys‖ := norm_le_pi_norm x_phys k
        linarith
      have h_prod_den :
          (∏ k : Fin n, ∏ μ : Fin 4, (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2) ≤
            (1 + ‖x_phys‖) ^ (8 * n) := by
        calc
          (∏ k : Fin n, ∏ μ : Fin 4, (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2)
              ≤ ∏ _k : Fin n, ∏ _μ : Fin 4, (1 + ‖x_phys‖) ^ 2 := by
                  refine Finset.prod_le_prod (fun _ _ => Finset.prod_nonneg fun _ _ => by positivity)
                    fun k _ => Finset.prod_le_prod (fun _ _ => by positivity) fun μ _ =>
                      pow_le_pow_left₀ (by positivity) (h_coord_le k μ) 2
          _ = (1 + ‖x_phys‖) ^ (8 * n) := by
                simp [Finset.prod_const, ← pow_mul]
      have h_f_bound : (1 + ‖x_phys‖) ^ (8 * n + 1) * ‖f x_phys‖ ≤ S_semi := by
        rw [add_comm, add_pow, Finset.sum_mul]
        dsimp [S_semi]
        have h82 : 8 * n + 1 + 1 = 8 * n + 2 := by ring
        rw [h82]
        refine Finset.sum_le_sum fun j _ => ?_
        have h_le_s : ‖x_phys‖ ^ j * ‖f x_phys‖ ≤ SchwartzMap.seminorm ℂ j 0 f := by
          simpa [norm_iteratedFDeriv_zero] using SchwartzMap.le_seminorm ℂ j 0 f x_phys
        calc
          ‖x_phys‖ ^ j * 1 ^ (8 * n + 1 - j) * ((8 * n + 1).choose j : ℝ) * ‖f x_phys‖
              = ((8 * n + 1).choose j : ℝ) * (‖x_phys‖ ^ j * ‖f x_phys‖) := by ring
          _ ≤ ((8 * n + 1).choose j : ℝ) * SchwartzMap.seminorm ℂ j 0 f :=
              mul_le_mul_of_nonneg_left h_le_s (Nat.cast_nonneg _)
      have h_a_eq : (∏ _k : Fin n, ∏ _μ : Fin 4, a) =
          (∏ k : Fin n, ∏ μ : Fin 4, (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2) *
          (∏ k : Fin n, ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2)) := by
        rw [← Finset.prod_mul_distrib]
        refine Finset.prod_congr rfl fun k _ => ?_
        rw [← Finset.prod_mul_distrib]
        refine Finset.prod_congr rfl fun μ _ => ?_
        have hne : (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2 ≠ 0 := by positivity
        field_simp [hne]
      have h_step_norm :
          (∏ k : Fin n, ∏ μ : Fin 4, (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2) * ‖f x_phys‖ ≤
            (8 / (a * (L : ℝ))) * S_semi := by
        have h1 : (∏ k : Fin n, ∏ μ : Fin 4, (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2) *
            ‖f x_phys‖ ≤ (1 + ‖x_phys‖) ^ (8 * n) * ‖f x_phys‖ :=
          mul_le_mul_of_nonneg_right h_prod_den (norm_nonneg _)
        have h2 : (1 + ‖x_phys‖) ^ (8 * n) * ‖f x_phys‖ ≤
            (8 / (a * (L : ℝ))) * ((1 + ‖x_phys‖) ^ (8 * n + 1) * ‖f x_phys‖) := by
          have h_mul1 : (1 + ‖x_phys‖) ^ (8 * n) ≤
              (8 / (a * (L : ℝ))) * (1 + ‖x_phys‖) ^ (8 * n + 1) := by
            calc
              (1 + ‖x_phys‖) ^ (8 * n) = (1 + ‖x_phys‖) ^ (8 * n) * 1 := by simp [mul_one]
              _ ≤ (1 + ‖x_phys‖) ^ (8 * n) * ((8 / (a * (L : ℝ))) * ‖x_phys‖) := by
                  gcongr
              _ ≤ (1 + ‖x_phys‖) ^ (8 * n) * ((8 / (a * (L : ℝ))) * (1 + ‖x_phys‖)) := by
                  gcongr; linarith
              _ = (8 / (a * (L : ℝ))) * (1 + ‖x_phys‖) ^ (8 * n + 1) := by ring
          calc
            (1 + ‖x_phys‖) ^ (8 * n) * ‖f x_phys‖
                ≤ ((8 / (a * (L : ℝ))) * (1 + ‖x_phys‖) ^ (8 * n + 1)) * ‖f x_phys‖ := by
                    gcongr
            _ = (8 / (a * (L : ℝ))) * ((1 + ‖x_phys‖) ^ (8 * n + 1) * ‖f x_phys‖) := by ring
        have h3 : (8 / (a * (L : ℝ))) * ((1 + ‖x_phys‖) ^ (8 * n + 1) * ‖f x_phys‖) ≤
            (8 / (a * (L : ℝ))) * S_semi :=
          mul_le_mul_of_nonneg_left h_f_bound (by positivity)
        exact le_trans h1 (le_trans h2 h3)
      rw [h_a_eq, mul_assoc]
      calc
        (∏ k : Fin n, ∏ μ : Fin 4, (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2) *
            ((∏ k : Fin n, ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2)) * ‖f x_phys‖)
            = ((∏ k : Fin n, ∏ μ : Fin 4, (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2) *
                ‖f x_phys‖) *
              (∏ k : Fin n, ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2)) := by ring
        _ ≤ ((8 / (a * (L : ℝ))) * S_semi) *
              (∏ k : Fin n, ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2)) :=
              mul_le_mul_of_nonneg_right h_step_norm
                (Finset.prod_nonneg fun _ _ => Finset.prod_nonneg fun _ _ => by positivity)
  have h_a4n : a ^ (4 * n) = ∏ _k : Fin n, ∏ _μ : Fin 4, a := by
    simp [Finset.prod_const, ← pow_mul, mul_comm]
  rw [h_a4n, Finset.mul_sum]
  calc
    ∑ xs : Fin n → Lat4 L,
        (∏ _k : Fin n, ∏ _μ : Fin 4, a) *
          (if InInteriorBox L n xs then 0 else ‖f (fun k => centeredLatSite L a (xs k))‖)
        ≤ ∑ xs : Fin n → Lat4 L,
            ((8 / (a * (L : ℝ))) * S_semi) *
              (∏ k : Fin n, ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2)) :=
          Finset.sum_le_sum fun xs _ => h_pointwise xs
    _ = ((8 / (a * (L : ℝ))) * S_semi) * ∑ xs : Fin n → Lat4 L,
          ∏ k : Fin n, ∏ μ : Fin 4, (a / (1 + a * |(centeredCoord L (xs k μ) : ℝ)|) ^ 2) :=
          (Finset.mul_sum _ _ _).symm
    _ ≤ ((8 / (a * (L : ℝ))) * S_semi) * (4096 : ℝ) ^ n := by
          refine mul_le_mul_of_nonneg_left h_nd (mul_nonneg (by positivity) ?_)
          exact Finset.sum_nonneg fun j _ => mul_nonneg (Nat.cast_nonneg _) (apply_nonneg _ _)
    _ = (8 / (a * (L : ℝ))) * (4096 : ℝ) ^ n * S_semi := by ring

end Imscribing.YangMills.LatticeExteriorCutoff4D